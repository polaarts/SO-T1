// observer.h
#ifndef OBSERVER_H
#define OBSERVER_H

void observer();

#endif
